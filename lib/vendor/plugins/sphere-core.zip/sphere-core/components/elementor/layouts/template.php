<?php

namespace Sphere\Core\Elementor\Layouts;
use \Bunyad;
use Elementor\Core\Base\Document;

/**
 * Template handlers.
 */
class Template
{
	public $types = [];

	public function __construct()
	{
		add_action('elementor/documents/register', [$this, 'register_documents']);
		add_action('wp_enqueue_scripts',[$this, 'enqueue_styles']);

		// 11 = after WooCommerce.
		add_filter('template_include', [$this, 'set_editor_template'], 11);

		/**
		 * Setup location handlers.
		 */

		// Change page template if one of the content locations have a custom layout.
		add_filter('template_include', function($current) {
			if (!$this->get_for_current('content')) {
				return $current;
			}

			$template = Module::instance()->path . 'page-templates/canvas.php';
			return apply_filters('sphere/el-layouts/page_template', $template);

		}, 99);

		// $filters = [
		// 	'bunyad_do_partial_archive' => 'ts-archive',
		// ];

		// foreach ($filters as $filter => $location) {
		// 	add_filter($filter, function() use ($location) {
		// 		return !$this->render_by_location($location);
		// 	});
		// }
	}

	public function enqueue_styles()
	{
		$templates = $this->get_for_current();
		if (!$templates) {
			return;
		}

		$css_files = [];
		$current_post_id = get_the_ID();

		foreach ($templates as $template_id) {

			// Don't enqueue current post here (let the  preview/frontend components to handle it)
			if ($current_post_id !== $template_id) {
				$css_files[] = new \Elementor\Core\Files\CSS\Post($template_id);
			}
		}

		if ($css_files) {
			\Elementor\Plugin::instance()->frontend->enqueue_styles();
			foreach ($css_files as $css_file) {
				$css_file->enqueue();
			}
		}
	}

	/**
	 * Set the template for CPT (hence the editor).
	 *
	 * @param string $template
	 * @return string
	 */
	public function set_editor_template($template)
	{
		if (!is_singular(Module::POST_TYPE)) {
			return $template;
		}

		// $doc_type = get_post_meta(get_the_ID(), Document::TYPE_META_KEY, true);

		$template = Module::instance()->path . 'page-templates/canvas.php';
		return apply_filters('sphere/el-layouts/editor_template', $template);
	}

	/**
	 * Get all the valid custom templates for current WP view.
	 *
	 * @param string $location Only for a specific location/part.
	 * @return array|string
	 */
	public function get_for_current($location = '')
	{
		$templates = [];

		if (is_archive()) {

			// Woocommerce doesn't respect is_post_type_archive().
			$is_woocommerce = class_exists('woocommerce') && is_woocommerce();

			if (Bunyad::options()->category_loop_custom && is_category()) {
				$templates['ts-archive'] = Bunyad::options()->category_loop_custom;
			}
			else if (Bunyad::options()->author_loop_custom && is_author()) {
				$templates['ts-archive'] = Bunyad::options()->author_loop_custom;
			}
			else if (Bunyad::options()->archive_loop_custom && !is_post_type_archive()) {
	
				// These have explicit settings, checked above.
				if (!$is_woocommerce && !is_author() && !is_search() && !is_category()) {
					$templates['ts-archive'] = Bunyad::options()->archive_loop_custom;
				}
			}
			else if (Bunyad::options()->cpt_loop_custom && is_post_type_archive()) {
				if (!$is_woocommerce) {
					$templates['ts-archive'] = Bunyad::options()->cpt_loop_custom;
				}
			}

			/**
			 * Setup template from term meta configs.
			 */
			$object = get_queried_object();
			if (is_object($object) && property_exists($object, 'term_id')) {
				$term_template = get_term_meta($object->term_id, '_bunyad_custom_template', true);

				if ($term_template) {
					$templates['ts-archive'] = $term_template;
				}

				// If it's none, the global shouldn't apply either.
				if ($term_template === 'none') {
					unset($templates['ts-archive']);
				}
			}
		}

		if ($location && isset($templates[$location])) {
			$templates = $templates[$location];
		}
		else if ($location === 'content') {
			/**
			 * Content locations have a single result, usually.
			 */
			$content_templates = array_intersect_key($templates, array_flip([
				'ts-archive'
			]));

			if (count($content_templates)) {
				$templates = current($content_templates);
			}
		}

		return apply_filters('sphere/el-layouts/location_templates', $templates, $location);
	}

	/**
	 * Render a template for a particular location.
	 *
	 * @param string $location
	 * @return boolean
	 */
	public function render_by_location($location)
	{
		$template = $this->get_for_current($location);
		if (!$template) {
			return false;
		}
		
		$this->render($template);
		return true;
	}

	public function render_content()
	{
		if (did_action('elementor/preview/init')) {
			return the_content();
		}

		$this->render_by_location('content');
	}

	public function render($template_id)
	{
		echo \Elementor\Plugin::instance()->frontend->get_builder_content($template_id, false); // XSS ok
	}

	public function register_documents($manager)
	{
		foreach (Module::instance()->types as $type) {
			$manager->register_document_type(
				$type['doc_id'], 
				'\Sphere\Core\Elementor\Layouts\Documents\\' . $type['doc_class']
			);
		}
	}
}