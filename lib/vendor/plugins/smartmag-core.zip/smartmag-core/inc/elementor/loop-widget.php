<?php

namespace Bunyad\Elementor;

/**
 * The base loop widget.
 */
class LoopWidget extends BaseWidget
{
	protected function _process_settings()
	{
		$settings = parent::_process_settings();

		// Default to custom query.
		if (!isset($settings['query_type'])) {
			$settings['query_type'] = 'custom';
		}

		// Section query if section_data available. Checking for query_type as section_query data
		// is only needed when the section query is used.
		if (isset($settings['section_data']) && $settings['query_type'] === 'section') {
			$settings['section_query'] = $settings['section_data'];
		}

		return $settings;
	}

	public function get_options($init_editor = false)
	{
		parent::get_options($init_editor);

		/**
		 * On editor, and on archives on front-end, change the default.
		 * 
		 * Note: This has to be done on front-end too, otherwise 'query_type' will
		 * default to the 'custom' instead.
		 */
		if ($init_editor || is_archive()) {
			$documents = \Elementor\Plugin::instance()->documents;

			// For AJAX requests load method of Elementor editor.
			if (isset($_REQUEST['editor_post_id'])) {
				$document = $documents->get($_REQUEST['editor_post_id']);
			} else {
				$document = $documents->get_current();
			}

			// Set query type to main for archive docs.
			if ($document && $document->get_type() === 'ts-archive') {
				$this->options->change_option('query_type', ['default' => 'main-custom']);
			}
		}

		return $this->options;
	}
}